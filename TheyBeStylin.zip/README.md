Adds a total of 48 skins to the game.  

Works with online multiplayer if both parties have the skins installed.  

```
Adds 4 skins for each survivor!
---

### Installation Instructions

Follow the instructions [listed here](https://docs.google.com/document/d/1NgLwb8noRLvlV9keNc_GF2aVzjARvUjpND2rxFgxyfw/edit?usp=sharing).


### Credits
* Groove_Salad.
* *RaptorMocha* made the skins.
